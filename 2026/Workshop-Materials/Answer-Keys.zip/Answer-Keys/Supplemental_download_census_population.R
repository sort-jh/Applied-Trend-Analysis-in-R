#----------------------------------------------------------------#
#               2026 CSTE Applied Trend Analysis in R            #
#       Download Population Data Using Census API Example        #
# Authors: Johns Hopkins Surveillance and Outbreak Response Team #
#----------------------------------------------------------------#

# If you don't have the data you can download demographic data using census API key
# Uses the census API via 'tidycensus' (requires you to get an API key)
# The code below is for reference on how to use the API key to pull census data

# List of packages used
pkgs <- c("tidyverse", "tidycensus")
# tidyverse contains lots of useful data management and manipulation packages and functions
# tidycensus uses the census API to download demographic data

# Installing any of the packages that you don't already have
install.packages(setdiff(pkgs, rownames(installed.packages())))

# Loading all the packages
lapply(pkgs, library, character.only = TRUE, quietly = TRUE, verbose = FALSE)

# Set your Census API key if you haven't already
# Users can request a free key at:
# https://api.census.gov/data/key_signup.html
census_api_key(
  "INSERT_YOUR_API_KEY_HERE",
  install = TRUE,
  overwrite = TRUE
)

# Years to pull
years <- 2010:2020

# Empty dataframe to store results
demo.total.in <- data.frame()

# Loop through years
for (yr in years) {
  
  if (yr == 2010) {
    
    # 2010 Decennial Census
    pop_data <- get_decennial(
      geography = "county",
      state = "MI",
      variables = "P001001",
      sumfile = "sf1",
      year = 2010,
      output = "wide"
    ) %>%
      mutate(
        year = yr,
        population = as.numeric(P001001)
      ) %>%
      select(GEOID, NAME, year, population)
    
  } else if (yr == 2020) {
    
    # 2020 Decennial Census
    pop_data <- get_decennial(
      geography = "county",
      state = "MI",
      variables = "P1_001N",
      sumfile = "pl",
      year = 2020,
      output = "wide"
    ) %>%
      mutate(
        year = yr,
        population = as.numeric(P1_001N)
      ) %>%
      select(GEOID, NAME, year, population)
    
  } else {
    
    # ACS 1-year estimates for 2011–2019
    pop_data <- get_acs(
      geography = "county",
      state = "MI",
      variables = "B01001_001",
      survey = "acs1",
      year = yr,
      output = "wide"
    ) %>%
      mutate(
        year = yr,
        population = as.numeric(B01001_001E)
      ) %>%
      select(GEOID, NAME, year, population)
  }
  
  # Append yearly data
  demo.total.in <- bind_rows(demo.total.in, pop_data)
}

# View results
head(demo.total.in)