#----------------------------------------------------------------#
#               2026 CSTE Applied Trend Analysis in R            #
#       Data Preparation and Trend Analysis - Demonstration      #
# Authors: Johns Hopkins Surveillance and Outbreak Response Team #
#----------------------------------------------------------------#

#---- Set-up #----

# List of packages used
pkgs <- c("excessmort", "tidyverse", "tidycensus", "ISOweek", "openxlsx")
# excessmort is the main package used for the excess calculation analysis
# tidyverse contains lots of useful data management and manipulation packages and functions
# tidycensus uses the census API to download demographic data (api key is required
# and can be requested here: "https://api.census.gov/data/key_signup.html")
# ISOweek helps convert week names to dates
# openxlsx lets us save tables from R as .xlsx files that can be opened in Excel

# Installing any of the packages that you don't already have
install.packages(setdiff(pkgs, rownames(installed.packages())))

# Loading all the packages
lapply(pkgs, library, character.only = TRUE, quietly = TRUE, verbose = FALSE)

# Setting working directory
# setwd("~/your_working_directory")

# Reading in full dataset of line list deaths in Michigan 2010-2020
mort.dat <- read_csv("linelist_2010-2020_mi.csv")
View(mort.dat)

# Current data includes the date of death for each person
# Since we want to run the analysis over weekly counts deaths,
# we need to figure out which week each death occurred in.
# We'll assign each date of death to a week of death called isoweek
mort.dat <- mort.dat %>%
  mutate(isoweek = paste0(isoyear(date), "-W", sprintf("%02d", isoweek(mort.dat$date)),"-1")) %>%
  # Pulling the date of the start of the week each death occurred
  mutate(isodate = ISOweek2date(isoweek)) %>%
  # Drop the 'date' column so it doesn't confuse any of our other
  # functions later in the analysis
  select(-date) %>%
  # Because we're counting by week, the start and end of our dataset don't represent
  # a complete week (1/1/2010 was a Friday, 12/31/2020 was a Thursday), which means
  # that mortality rates for these weeks are going to look lower. We'll drop data
  # from these weeks here, but if you want to analyze a full year of your real
  # data at a weekly level, make sure you have the complete weeks at the beginning
  # and end.
  filter(isoweek != "2009-W53-1" & isoweek != "2020-W53-1")

# Details about code for assigning a date to an ISO week
# ISO week is a standardized way of representing weeks in calendar year
# Weeks start on Monday, Week 1 of a year is the week that contains first Thurs
# The format of ISO 8601 week date format is YYYY-Www-D
# A year can have 52 or 53 weeks
# isoyear(date) gives the ISO 8601 year
# isoweek(date) gives the ISO week number (1-53)
# W indicates that what follows is a week number
# ww is the week number (1-53)
# D is day of the week (1 = Monday, 7 = Sunday)
# sprintf pads week numbers with leading zeros if needed
# paste0 brings all these parts together to make the date


#---- Download Population Counts #----

# We want to analyze trends in mortality according to cause of death and county,
# so we need population totals for each of these groups so we can calculate group-
# specific rates of death. These population totals can also change over the time period
# of interest (2010 - 2020), so we should make sure we have fresh numbers for each
# year to account for those potential differences over time.

# For cause of death, we'll consider the entire population to be at risk, so we
# can use the same population total data from the full analysis. For certain outcomes,
# pregnancy and perinatal deaths, for example, this wouldn't be true so we would
# want to use only female population (or whatever specific population is at risk
# for the outcome under study), but to simplify things here, we'll just just the
# whole population with the assumption that the sex ratio (i.e. the # of males vs.
# females in Michigan) did not change significantly from 2010-2020.

# You can either read in your own locally stored demographic dataset as long
# as it has columns named for each of the variables you plan to
# subset by in your full dataset

# For today, just download the prepared population dataset called population_data.csv:
demo.total.in <- read_csv("population_data.csv")

# Checking to make sure all years have been read in
data.frame(
  year = seq(from = min(year(mort.dat$isodate), na.rm = TRUE),
             to = max(year(mort.dat$isodate), na.rm = TRUE),
             by = 1)) %>%
  mutate(dl = if_else(year %in% demo.total.in$year, "Yes", "No"))


#---- Extrapolate Population Counts #----

# Now we need to convert this table of annual population into a long list of population
# size for each day in our line list. We'll use the 'approx_demographics' function
# from the 'excessmort' package
demo.total <- approx_demographics(
  # Name the original demographic table
  demo = demo.total.in,
  # Define the first date that deaths occurred (since we're analyzing at the week
  # level, this is actually the first date of the first week deaths occurred)
  first_day = min(mort.dat$isodate),
  # Define the last date
  last_day = max(mort.dat$isodate),
  # Since we don't have population data for each day or week of each year,
  # we use the population data we do have to extrapolate the time in between.
  # extrapoloation.type can be constant (i.e. each day of 2015 would have
  # the same population total until the number is updated with 2016 data),
  # or can be linear (assume a linear change from year 1 to year 2 and impute the
  # change along the way). In this case we need to fill in the
  # gaps so we'll use a linear extrapolation that will assume the population
  # changed at a fixed rate between the times that we've provided in the
  # 'demo.total.in' table.
  extrapolation.type = "linear")


#---- Identify Period of Interest and Aggregate to Weekly Data #----

# We want to evaluate whether there were excess deaths during the pandemic, so
# we need to define the exclusion period for our analysis just like for the full
# dataset. We will call this the "period of interest" moving forward.
# The first COVID-19 case was reported in Michigan on March 10, 2020
# We will create a list of dates after which we want to calculate excess
# This is basically all of the dates that we don't want to train our expected counts on
pandemic.dates <- seq.Date(as.Date("2020-03-10"),
                           as.Date("2020-12-31"),
                           by = "day")

# Finally, we need to aggregate the individual level data into weekly count data
# and we use compute_counts() to do so which is part of the excessmort package
all.counts <- compute_counts(dat = mort.dat, # df with individual records
                             demo = demo.total, # df with population sizes for each time point
                             # We want to use weekly counts so we specify date
                             # as the Monday of every week
                             date = "isodate")

# Export data for next step
saveRDS(all.counts,"all_counts.rds")

#---- Rare Outcomes Check: Assessing How Frequently Events Occur #----

# When is it appropriate to do a rare events analysis using the excessmort package?
# Need to meet a minimum of 0.10 events per day in the baseline period.
# Let's check if our dataset meets the minimum.

# Now that we have set our baseline period, with rare outcomes we want to be sure
# that the rate of the outcome occurring meets the >= 0.1 events/day threshold
# determined by the creators of the excessmort() package. If we run into issues
# later in the code, we can come back to this section to see if any weeks are
# causing trouble and we should consider shifting the study time period.

# Let's check if the rate of mortality is >= 0.1 events/day in the
# baseline period. To do this, since our data are in weeks, we need to calculate 
# the events per week and convert it to a daily rate by dividing by 7

## Mortality events per week ####
mort.dat$count <- 1
tab_baseline <- filter(mort.dat, isoweek < "2020-W11-1") # March 10, 2020 is in Week 11
tab_baseline <- aggregate(count ~ isoweek, data = tab_baseline, FUN = sum, na.rm = TRUE)
tab_baseline$mort_events_daily <- tab_baseline$count / 7 # Get daily count
names(tab_baseline)[names(tab_baseline) == "count"] <- "mort_events_weekly"
head(tab_baseline)

# Print weeks where events/day is < 0.1
tab_baseline$isoweek[tab_baseline$mort_events_daily < 0.1]
# there are no individual weeks that don't meet the minimum daily rate of events 
# to be included in the event period

# Let's check whether the dataset overall meets the threshold of 0.1 events/day
# (equivalent to ~0.7 events/week) for the baseline period. This ensures we have 
# enough data for reliable estimation.

# Now let's check for the rate over the whole baseline period
# How many weeks in full period and baseline period (preceding the event period)
n_weeks_baseline <- nrow(tab_baseline)

# Count total mortality events across all weeks
total_events_baseline <- sum(tab_baseline$mort_events_weekly, na.rm = TRUE)

# Calculate average events per day and week across entire  period
overall_daily_rate <- total_events_baseline / (n_weeks_baseline * 7)

# Display result
overall_daily_rate

# Interpretation:
# If this value is >= 0.1 per day, or >=0.7 per week, then we can proceed with 
# the rare event analysis using excessmort(). Otherwise, the event is too rare 
# to estimate stable excess mortality metrics. Proceed with caution!

